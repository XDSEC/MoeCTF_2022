from Crypto.Util.number import*
from Crypto.Cipher import AES
from aes import AES_CBC
from secret import key1,key2,IV,K

def encrypt(plaintext,key):
    assert len(plaintext) == 32
    assert len(key) == 16

    left = plaintext[:16]
    right = plaintext[16:]

    for i in range(3):
        aes = AES.new(key,AES.MODE_ECB)
        new_right = long_to_bytes(bytes_to_long(aes.encrypt(right)) ^ bytes_to_long(left))
        new_left = right
        left = new_left
        right = new_right
    return left + right

def decrypt(ciphertext,key):
    assert len(ciphertext) == 32
    assert len(key) == 16

    left = ciphertext[:16]
    right = ciphertext[16:]

    for i in range(3):
        aes = AES.new(key,AES.MODE_ECB)
        last_right = left
        last_left = long_to_bytes(bytes_to_long(right) ^ bytes_to_long(aes.encrypt(left)))
        left = last_left
        right = last_right  
    return left + right
    
M = K+IV
cipher = encrypt(M,key1)
cipher = decrypt(cipher,key2)
cipher = encrypt(cipher,key1)
