from Crypto.Cipher import AES
from secret import K,IV,data

class AES_CBC(object):
  def __init__(self,key,iv):
    self.key=key
    self.mode=AES.MODE_CBC
    self.iv=iv
 
  def pad_byte(self, b):
    bytes_num_to_pad = AES.block_size - (len(b) % AES.block_size)
    return b + bytes([bytes_num_to_pad]) * bytes_num_to_pad
 
  def encrypt(self,text):
    cryptor = AES.new(self.key,self.mode,self.iv)
    text = self.pad_byte(text)
    self.ciphertext = cryptor.encrypt(text)
    return self.ciphertext
 
  def decrypt(self,text):
    unpad = lambda s: s[:-ord(s[len(s) - 1:])]
    cryptor = AES.new(self.key, self.mode, self.iv)
    aesStr = cryptor.decrypt(text)
    aesStr = str(unpad(aesStr), encoding='utf8')
    return aesStr

pc=AES_CBC(K, IV)
encdata = pc.encrypt(data)